<?php 

$con = mysqli_connect("localhost","naurifecommerce","naurifecommerce","naurif");

?>
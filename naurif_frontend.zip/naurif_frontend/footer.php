<footer class="footer-container typefooter-1">
        <div class="row debit-cards">
            <div class="col-md-12">
                <ul class="debit-cards1">
                    <li><a href="#">Debit card</a></li>
                    <li><a href="#">Credit card</a></li>
                    <li><a href="#">Net Banking</a></li>
                </ul>
                <ul class="card-imgaes">
                    <li><a href="#"><img src="image/visa.png" alt="visa card"></a></li>
                    <li><a href="#"><img src="image/master1.png" alt="master card"></a></li>
                    <li><a href="#"><img src="image/RuPay1.png" alt="RuPay card"></a></li>
                    <li><a href="#"><img src="image/american1.jpg" alt="American card"></a></li>
                    <li><a href="#"><img src="image/bhim1.png" alt="Hhim card"></a></li>
          
                </ul>
            </div>
        
        </div>
        <hr>
        <div class="row social-icons">
            <div class="col-md-12">
                <h4>Follow us</h4>
                <ul>
                    <li><a href="#"><i class="fa fa-facebook facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest pinterest"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube youtube"></i></a></li>
                </ul>
                <p>&copy; Naurif marketing pvt ltd. all rights reserved.</p>
            </div>
        </div>